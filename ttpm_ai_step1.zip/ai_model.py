"""用于 TicTacToePM 的基础 CNN 策略网络。"""
from __future__ import annotations

import torch
from torch import nn


class PolicyCNN(nn.Module):
    """输入 (batch, 5, 9, 9)，输出 81 个落子动作的 logits。"""

    def __init__(self, in_channels=5, action_size=81):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(),
        )
        self.policy_head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 9 * 9, 256),
            nn.ReLU(),
            nn.Linear(256, action_size),
        )

    def forward(self, x):
        return self.policy_head(self.features(x))


def mask_illegal_actions(logits, legal_mask):
    """将非法动作 logits 设为极小值，softmax 后不会被选中。"""
    return logits.masked_fill(~legal_mask.bool(), torch.finfo(logits.dtype).min)
