# TicTacToePM AI 第一步：环境与 CNN

## 新增文件
- `ai_environment.py`：把现有 `GameEngine` 包装成强化学习可用的状态、合法动作掩码和 step 接口。
- `ai_model.py`：基础 PyTorch CNN 策略网络，输出 81 个动作的分数。
- `test_ai_environment.py`：验证状态形状、合法动作掩码和规则一致性。

现有 `game_engine.py` 与 `main.py` 不需要修改。

## 依赖
在项目独立的 `.venv` 中安装 NumPy（PyTorch 通常也会安装 NumPy，但单独确认更稳妥）：
```powershell
python -m pip install numpy
```

## 测试
把这三个 `.py` 文件放到与 `game_engine.py` 相同的项目根目录，再运行：
```powershell
python -m unittest -v test_ai_environment.py
python -m unittest -v test_game_engine.py
```

## 状态编码
每个状态是 `(5, 9, 9)` 的 `float32` 数组：
1. 当前玩家棋子；
2. 对手棋子；
3. 3x3 中格结果扩展到各自 3x3 小格区域；
4. 当前强制中格；
5. 当前玩家标记。

动作编号 `a = row * 9 + col`，范围 `0..80`。通过合法动作掩码屏蔽规则不允许的位置。

## 说明
这是训练管线的第一步，不包含训练循环，也不改变 GUI。下一步再添加自我对弈采样和 REINFORCE 训练脚本。
