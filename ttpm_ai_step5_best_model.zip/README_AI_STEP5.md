# Actor-Critic 训练：保留最佳模型

## 替换文件
将压缩包中的 `train_selfplay.py` 和 `evaluate_model.py` 覆盖项目根目录中的同名文件。保留 `ai_environment.py`、`ai_model.py`（ActorCriticCNN 版本）及 `game_engine.py`。

## 重要的模型文件
- `checkpoints_ac/policy_latest.pt`：最新训练状态，继续训练时从这里恢复，会被覆盖。
- `checkpoints_ac/policy_best.pt`：仅当对随机合法策略的评估分数严格高于历史最佳时才覆盖。

评估分数 = (胜场 + 0.5 × 平局) / 总局数。评估中模型 O/X 尽量均分，模型采用贪心落子，随机对手从合法动作中随机选。

## 先验证
```powershell
python train_selfplay.py --episodes 20 --save-every 10 --eval-every 20 --eval-games 20 --log-every 1 --device cuda
```

首次评估后会建立 `policy_best.pt`。评估对局数较少时分数噪声较大，只用于验证流程。

## 多轮训练
```powershell
python train_selfplay.py --episodes 500 --resume --device cuda --eval-every 100 --eval-games 40
```
每次再次运行同一条命令即可继续训练。`policy_latest.pt` 会更新；`policy_best.pt` 只在评估得分超过历史记录时更新。

## 查看当前优选模型
```powershell
python evaluate_model.py
```
新版 `evaluate_model.py` 优先加载 `policy_best.pt`，若不存在才加载 `policy_latest.pt`。

## 重要限制
随机合法策略只是初级基准。若想可靠比较模型，建议后续加入固定测试集、多个随机种子以及历史模型对手池。因为评估样本有限，某一轮分数提高也可能来自随机波动；“best”仅表示在当前随机对手基准上的历史最高分，不等于绝对最强模型。
