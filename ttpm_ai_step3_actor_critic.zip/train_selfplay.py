"""TicTacToePM Actor-Critic 自我对弈训练器。

建议先小规模验证：
python train_selfplay.py --episodes 20 --device cuda

正式训练：
python train_selfplay.py --episodes 1000 --device cuda

新模型保存到 checkpoints_ac/policy_latest.pt，不覆盖旧版 REINFORCE 模型。
"""
from __future__ import annotations

import argparse
import os
import random
import time

import numpy as np
import torch
from torch import nn, optim
from torch.distributions import Categorical

from ai_environment import TicTacToeEnv
from ai_model import ActorCriticCNN, mask_illegal_actions


def choose_device(requested):
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA 不可用。请检查项目 .venv 的 PyTorch 安装。")
    return device


def select_action(model, state, legal_mask, device, temperature):
    state_t = torch.as_tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
    mask_t = torch.as_tensor(legal_mask, dtype=torch.bool, device=device).unsqueeze(0)
    logits, value = model(state_t)
    logits = mask_illegal_actions(logits, mask_t) / temperature
    dist = Categorical(logits=logits)
    action = dist.sample()
    return int(action.item()), dist.log_prob(action).squeeze(0), value.squeeze(0)


def save_checkpoint(model, optimizer, episode, totals, checkpoint_dir, device):
    os.makedirs(checkpoint_dir, exist_ok=True)
    path = os.path.join(checkpoint_dir, "policy_latest.pt")
    # 保存普通 tensor/数字/字符串，加载时可以使用 weights_only=True。
    torch.save({
        "episode": int(episode),
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "totals": {key: int(value) for key, value in totals.items()},
        "algorithm": "actor_critic_monte_carlo",
        "device": str(device),
    }, path)
    print(f"检查点已保存：{path}")


def main():
    parser = argparse.ArgumentParser(description="TicTacToePM Actor-Critic 自我对弈")
    parser.add_argument("--episodes", type=int, default=200)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--checkpoint-dir", default="checkpoints_ac")
    parser.add_argument("--save-every", type=int, default=25)
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    if args.episodes < 1:
        parser.error("--episodes must be >= 1")
    if args.lr <= 0 or args.temperature <= 0:
        parser.error("--lr and --temperature must be > 0")
    if args.save_every < 1 or args.log_every < 1:
        parser.error("--save-every and --log-every must be >= 1")

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    device = choose_device(args.device)
    if device.type == "cuda":
        print(f"训练设备：{torch.cuda.get_device_name(device)}")
    else:
        print("训练设备：CPU")

    env = TicTacToeEnv()
    model = ActorCriticCNN().to(device)
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    start_episode = 1
    totals = {"o_wins": 0, "x_wins": 0, "draws": 0}

    checkpoint_path = os.path.join(args.checkpoint_dir, "policy_latest.pt")
    if args.resume:
        if not os.path.isfile(checkpoint_path):
            raise FileNotFoundError(f"找不到续训模型：{checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
        model.load_state_dict(checkpoint["model_state_dict"])
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        start_episode = int(checkpoint["episode"]) + 1
        totals.update(checkpoint.get("totals", {}))
        print(f"从第 {start_episode} 局继续训练")

    started = time.time()
    for episode in range(start_episode, start_episode + args.episodes):
        env.reset()
        # 每条记录都是“轮到该玩家时”的状态，value 与该玩家视角一致。
        trajectory = []
        for _ in range(81):
            state = env.get_state()
            legal = env.legal_action_mask()
            if not legal.any():
                break
            player = env.game.current_player
            action, log_prob, value = select_action(
                model, state, legal, device, args.temperature
            )
            trajectory.append((log_prob, value, player))
            _, _, done, _ = env.step(action)
            if done:
                break

        winner = env.game.winner
        draw = env.game.draw
        if draw:
            totals["draws"] += 1
        elif winner == 1:
            totals["o_wins"] += 1
        elif winner == -1:
            totals["x_wins"] += 1

        # Monte Carlo 终局目标：每一步以该步行动者的视角获得 +1/-1/0。
        # 价值头拟合终局结果；策略头使用 (结果 - 价值估计) 作为优势。
        if trajectory:
            log_probs = torch.stack([item[0] for item in trajectory])
            values = torch.stack([item[1] for item in trajectory])
            targets = torch.tensor(
                [
                    0.0 if draw or winner == 0
                    else (1.0 if player == winner else -1.0)
                    for _, _, player in trajectory
                ],
                dtype=torch.float32,
                device=device,
            )
            advantages = targets - values.detach()
            policy_loss = -(log_probs * advantages).mean()
            value_loss = nn.functional.smooth_l1_loss(values, targets)
            # 熵奖励鼓励初期探索，但不让熵项压过策略目标。
            # 为了避免二次前向图复杂化，此版先采用策略 + 价值两项损失。
            loss = policy_loss + 0.5 * value_loss

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

        completed = episode - start_episode + 1
        if completed % args.log_every == 0 or completed == 1:
            games = sum(totals.values())
            print(
                f"局数 {episode} | O胜 {totals['o_wins']} "
                f"| X胜 {totals['x_wins']} | 平局 {totals['draws']} "
                f"| 累计局数 {games} | 用时 {time.time() - started:.1f}s"
            )

        if completed % args.save_every == 0:
            save_checkpoint(model, optimizer, episode, totals, args.checkpoint_dir, device)

    last_episode = start_episode + args.episodes - 1
    save_checkpoint(model, optimizer, last_episode, totals, args.checkpoint_dir, device)
    print("训练结束。建议再运行 evaluate_model.py 检查模型能否加载并选择合法动作。")


if __name__ == "__main__":
    main()
