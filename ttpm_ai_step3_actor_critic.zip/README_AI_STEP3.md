# TicTacToePM AI 第三阶段：Actor-Critic

## 安装前提
保留第一阶段的 `ai_environment.py`。新版 `ai_model.py`、`train_selfplay.py`、`evaluate_model.py` 替换项目根目录中同名文件。

## 重要：使用新的检查点目录
新版模型结构与旧版 REINFORCE 不同，不能加载旧的 `checkpoints/policy_latest.pt`。
新版默认使用 `checkpoints_ac/policy_latest.pt`，不会覆盖旧模型。

## 先小规模运行
```powershell
python train_selfplay.py --episodes 20 --save-every 5 --log-every 1 --device cuda
```

## 检查模型
```powershell
python evaluate_model.py
```

## 正式训练
```powershell
python train_selfplay.py --episodes 1000 --save-every 50 --log-every 10 --device cuda
```

## 继续训练
```powershell
python train_selfplay.py --episodes 500 --resume --device cuda
```

`--episodes` 表示本次新增对局数。`--resume` 从 `checkpoints_ac/policy_latest.pt` 继续。

## 算法说明
- Actor 输出 81 个动作的 logits，非法动作在采样前屏蔽。
- Critic 预测当前玩家视角的终局结果，输出范围约为 [-1, 1]。
- 每局结束后按每一步行动者的视角生成 +1、-1 或 0 的 Monte Carlo 目标。
- 策略损失使用终局结果减去价值预测作为优势；价值损失拟合终局目标。
- 这是可运行的基础 Actor-Critic 自我对弈实现，不是 AlphaZero，也没有 MCTS、经验回放或对手池。要可靠评估棋力，后续应增加固定随机对手、旧版本模型对手以及先后手分开统计。
