"""加载 Actor-Critic 模型，并检查其初始局面的合法落子。"""
import os

import torch

from ai_environment import TicTacToeEnv
from ai_model import ActorCriticCNN, mask_illegal_actions


def main():
    checkpoint_path = os.path.join("checkpoints_ac", "policy_latest.pt")
    if not os.path.isfile(checkpoint_path):
        raise FileNotFoundError(
            f"找不到 {checkpoint_path}。请先运行新版 train_selfplay.py。"
        )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 新版检查点由本项目脚本生成，内容仅含张量和基础数据。
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
    model = ActorCriticCNN().to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    env = TicTacToeEnv()
    state = env.reset()
    legal = env.legal_action_mask()
    with torch.no_grad():
        state_t = torch.as_tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
        mask_t = torch.as_tensor(legal, dtype=torch.bool, device=device).unsqueeze(0)
        logits, value = model(state_t)
        logits = mask_illegal_actions(logits, mask_t)
        action = int(torch.argmax(logits, dim=1).item())

    row, col = divmod(action, 9)
    print(f"模型加载成功：{checkpoint_path}")
    print(f"设备：{device}")
    print(f"初始局面价值估计（当前玩家视角）：{float(value.item()):.3f}")
    print(f"推荐落子：第 {row + 1} 行、第 {col + 1} 列")
    print(f"动作是否合法：{bool(legal[action])}")


if __name__ == "__main__":
    main()
