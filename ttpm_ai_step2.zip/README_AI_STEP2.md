# TicTacToePM AI 第二步：自我对弈训练

## 先决条件
- 已放置第一步文件：`ai_environment.py`、`ai_model.py`
- `game_engine.py` 位于同一目录
- 项目 `.venv` 中已安装 PyTorch（CUDA 13.2）与 NumPy

## 开始训练
在 Visual Studio 终端确认使用项目 `.venv`，进入 `TicTacToePM` 根目录：

```powershell
python train_selfplay.py --episodes 200 --device cuda
```

训练会定期在 `checkpoints/policy_latest.pt` 保存模型。可先用 10 局验证程序能正常运行：

```powershell
python train_selfplay.py --episodes 10 --save-every 5 --log-every 1 --device cuda
```

## 继续训练
程序会覆盖保存最新检查点。继续之前的训练：

```powershell
python train_selfplay.py --episodes 200 --resume --device cuda
```

`--episodes` 表示本次新增对局数，不是训练结束时的总局数。

## 检查模型
```powershell
python evaluate_model.py
```

该脚本加载模型并确认初始局面推荐的动作合法。

## 训练算法说明与限制
- 两方使用同一个共享 CNN 策略网络，以当前玩家视角编码棋盘。
- 每一步只从 `GameEngine.available_moves()` 返回的合法动作中采样。
- 每局结束后，获胜方的动作获得 +1，失败方动作获得 -1，平局动作获得 0。
- 这是用于搭建端到端流程的基础 REINFORCE 版本。单局终局奖励方差较大，模型也可能偏向 O 或 X 的座位表现；请先验证程序正确性，不要把少量对局的胜率当成可靠棋力指标。
- GUI 尚未修改；人机对战集成将在训练流程稳定后单独完成。
