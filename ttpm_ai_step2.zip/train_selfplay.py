"""TicTacToePM CNN 自我对弈强化学习训练脚本。

在项目根目录运行：
    python train_selfplay.py --episodes 200 --checkpoint-dir checkpoints

该脚本使用简单的 REINFORCE：每局结束后，以最终胜负作为该局每一步动作的回报。
这是易于理解的第一版训练器；不是保证快速达到高棋力的算法。
"""
from __future__ import annotations

import argparse
import os
import random
import time

import numpy as np
import torch
from torch import optim
from torch.distributions import Categorical

from ai_environment import TicTacToeEnv
from ai_model import PolicyCNN, mask_illegal_actions


def choose_device(requested: str) -> torch.device:
    """选择训练设备；指定 cuda 但不可用时直接报错，避免悄悄改用 CPU。"""
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(
            "指定了 CUDA，但 torch.cuda.is_available() 为 False。"
            "请先检查当前虚拟环境中的 PyTorch/CUDA 安装。"
        )
    return device


def sample_action(model, state: np.ndarray, legal_mask: np.ndarray,
                  device: torch.device, temperature: float):
    """从合法动作中按策略分布采样，返回动作与该动作的 log probability。"""
    state_tensor = torch.from_numpy(state).unsqueeze(0).to(device)
    mask_tensor = torch.from_numpy(legal_mask).unsqueeze(0).to(device)

    logits = model(state_tensor)
    logits = mask_illegal_actions(logits, mask_tensor)
    # 温度越低越偏向高分动作；保留采样可以让初期探索更多棋路。
    logits = logits / max(temperature, 1e-3)
    distribution = Categorical(logits=logits)
    action_tensor = distribution.sample()
    return int(action_tensor.item()), distribution.log_prob(action_tensor).squeeze(0)


def save_checkpoint(model, optimizer, episode, wins, draws, losses,
                    checkpoint_dir, device):
    os.makedirs(checkpoint_dir, exist_ok=True)
    path = os.path.join(checkpoint_dir, "policy_latest.pt")
    torch.save({
        "episode": episode,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "wins": wins,
        "draws": draws,
        "losses": losses,
        "torch_version": torch.__version__,
        "device": str(device),
    }, path)
    print(f"已保存检查点：{path}")


def main():
    parser = argparse.ArgumentParser(description="TicTacToePM CNN 自我对弈训练")
    parser.add_argument("--episodes", type=int, default=200,
                        help="训练对局数，默认 200")
    parser.add_argument("--lr", type=float, default=1e-4,
                        help="学习率，默认 0.0001")
    parser.add_argument("--temperature", type=float, default=1.0,
                        help="动作采样温度，默认 1.0")
    parser.add_argument("--checkpoint-dir", default="checkpoints",
                        help="模型保存目录")
    parser.add_argument("--save-every", type=int, default=25,
                        help="每多少局保存一次")
    parser.add_argument("--log-every", type=int, default=10,
                        help="每多少局打印一次统计")
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto",
                        help="训练设备，默认自动选择")
    parser.add_argument("--seed", type=int, default=42,
                        help="随机种子")
    parser.add_argument("--resume", action="store_true",
                        help="若存在 policy_latest.pt，则从该检查点继续")
    args = parser.parse_args()

    if args.episodes <= 0:
        parser.error("--episodes 必须大于 0")
    if args.save_every <= 0 or args.log_every <= 0:
        parser.error("--save-every 和 --log-every 必须大于 0")
    if args.temperature <= 0:
        parser.error("--temperature 必须大于 0")

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    device = choose_device(args.device)
    if device.type == "cuda":
        print(f"训练设备：{torch.cuda.get_device_name(device)}")
    else:
        print("训练设备：CPU")

    env = TicTacToeEnv()
    model = PolicyCNN().to(device)
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    start_episode = 1
    total_wins = total_draws = total_losses = 0
    checkpoint_path = os.path.join(args.checkpoint_dir, "policy_latest.pt")
    if args.resume and os.path.isfile(checkpoint_path):
        checkpoint = torch.load(checkpoint_path, map_location=device)
        model.load_state_dict(checkpoint["model_state_dict"])
        if "optimizer_state_dict" in checkpoint:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        start_episode = int(checkpoint.get("episode", 0)) + 1
        total_wins = int(checkpoint.get("wins", 0))
        total_draws = int(checkpoint.get("draws", 0))
        total_losses = int(checkpoint.get("losses", 0))
        print(f"从第 {start_episode} 局继续训练")

    started = time.time()
    for episode in range(start_episode, start_episode + args.episodes):
        env.reset()
        # 每个样本存下当前玩家视角的状态、动作 log-prob 和该玩家身份。
        trajectory = []
        max_steps = 81

        for _ in range(max_steps):
            state = env.get_state()
            legal_mask = env.legal_action_mask()
            if not legal_mask.any():
                # 正常规则下终局应已被标记；此处是防御性检查。
                break

            player = env.game.current_player
            action, log_prob = sample_action(
                model, state, legal_mask, device, args.temperature
            )
            trajectory.append((log_prob, player))
            _, _, done, info = env.step(action)
            if done:
                break

        winner = env.game.winner
        draw = env.game.draw
        if winner == 1:
            total_wins += 1
        elif winner == -1:
            total_losses += 1
        else:
            total_draws += 1

        # 用终局结果给每一步动作分配回报。平局回报为 0。
        log_probs = []
        rewards = []
        for log_prob, player in trajectory:
            if draw or winner == 0:
                reward = 0.0
            elif winner == player:
                reward = 1.0
            else:
                reward = -1.0
            log_probs.append(log_prob)
            rewards.append(reward)

        if log_probs:
            reward_tensor = torch.tensor(rewards, dtype=torch.float32, device=device)
            # 简单中心化降低梯度偏移；单局全胜/全负时仍保留信号。
            if reward_tensor.std(unbiased=False).item() > 0:
                reward_tensor = (reward_tensor - reward_tensor.mean()) / (
                    reward_tensor.std(unbiased=False) + 1e-6
                )
            log_prob_tensor = torch.stack(log_probs)
            loss = -(log_prob_tensor * reward_tensor).mean()

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

        completed = episode - start_episode + 1
        if completed % args.log_every == 0 or completed == 1:
            games = total_wins + total_draws + total_losses
            win_rate = 100.0 * total_wins / max(games, 1)
            draw_rate = 100.0 * total_draws / max(games, 1)
            elapsed = time.time() - started
            print(
                f"局数 {episode} | O胜 {total_wins} | 平局 {total_draws} "
                f"| X胜 {total_losses} | O胜率 {win_rate:.1f}% "
                f"| 平局率 {draw_rate:.1f}% | 用时 {elapsed:.1f}s"
            )

        if completed % args.save_every == 0:
            save_checkpoint(
                model, optimizer, episode, total_wins, total_draws, total_losses,
                args.checkpoint_dir, device
            )

    last_episode = start_episode + args.episodes - 1
    save_checkpoint(
        model, optimizer, last_episode, total_wins, total_draws, total_losses,
        args.checkpoint_dir, device
    )
    print("训练结束。注意：O/X 统计是座位胜负统计，不等同于模型的整体棋力。")


if __name__ == "__main__":
    main()
