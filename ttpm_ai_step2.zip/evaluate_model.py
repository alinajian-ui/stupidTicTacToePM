"""快速检查已保存 CNN 模型是否可加载、是否能给出合法动作。"""
import os
import numpy as np
import torch

from ai_environment import TicTacToeEnv
from ai_model import PolicyCNN, mask_illegal_actions


def main():
    checkpoint_path = os.path.join("checkpoints", "policy_latest.pt")
    if not os.path.isfile(checkpoint_path):
        raise FileNotFoundError(
            f"找不到 {checkpoint_path}。请先运行 train_selfplay.py 完成至少一局训练。"
        )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model = PolicyCNN().to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    env = TicTacToeEnv()
    state = env.reset()
    legal = env.legal_action_mask()
    with torch.no_grad():
        state_tensor = torch.from_numpy(state).unsqueeze(0).to(device)
        mask_tensor = torch.from_numpy(legal).unsqueeze(0).to(device)
        logits = mask_illegal_actions(model(state_tensor), mask_tensor)
        action = int(torch.argmax(logits, dim=1).item())

    row, col = divmod(action, 9)
    print(f"模型加载成功：{checkpoint_path}")
    print(f"设备：{device}")
    print(f"初始局面推荐落子：第 {row + 1} 行、第 {col + 1} 列")
    print(f"该动作是否合法：{bool(legal[action])}")


if __name__ == "__main__":
    main()
